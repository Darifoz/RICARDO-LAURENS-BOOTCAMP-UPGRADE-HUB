const allCharacters$$ = document.body.querySelectorAll('[data-function="testMe"]');

console.log(allCharacters$$);