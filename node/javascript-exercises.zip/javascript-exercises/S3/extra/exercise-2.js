const p$$ = document.querySelector('.fn-remove-me');

p$$.remove();