const p$$ = document.createElement('p');

p$$.textContent = 'Soy dinámico!';

document.body.appendChild(p$$);