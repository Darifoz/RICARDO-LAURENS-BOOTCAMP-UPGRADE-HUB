const firstName = 'Jon'; 
const lastName = 'Snow'; 
const age = 24; 

console.log('Soy ' + firstName + ' ' + lastName +', Tengo ' + age + ' años y me gustan los lobos.')