const x = 5;
const y = 10;
const z = x + y;