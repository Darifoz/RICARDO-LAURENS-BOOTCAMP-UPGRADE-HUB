const removeMeAll$$ = document.querySelectorAll('.fn-remove-me');

for (const removeMe$$ of removeMeAll$$) {
    removeMe$$.remove();
}