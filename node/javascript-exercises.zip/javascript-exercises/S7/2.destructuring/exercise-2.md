En base al siguiente javascript, usa destructuring para crear 3 variables llamadas fruit1, fruit2 y fruit3, con los valores del array. Posteriormente imprimelo por consola.


```js
const fruits = ['Banana', 'Strawberry', 'Orange'];
```