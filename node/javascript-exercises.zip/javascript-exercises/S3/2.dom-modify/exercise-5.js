const h2$$ = document.body.querySelector('h2');

h2$$.textContent = 'Wubba Lubba dub dub';