const showMeButton$ = document.body.querySelector('.showme');
console.log(showMeButton$);