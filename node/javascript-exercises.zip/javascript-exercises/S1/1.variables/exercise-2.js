var x = 50;
// let x = 50;
// const x = 50;