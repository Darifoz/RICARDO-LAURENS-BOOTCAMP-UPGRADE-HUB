Al siguiente javascript no funciona como deberia...podrias arreglarlo?

Debería mostrar por consola "Juan Pui".

```js
function a(){
    const name = "Juan Pui";
    b(name);
}

function b(){
    console.log(name)
}

a();
```